from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
from blogApp import views


urlpatterns = [
    
    path('Home/', views.Home, name='Home'),
    path('search/',views.searchdata,name='search'),
    path('', views.index, name='index'),
    path('services',views.services, name='services'),
    path('firststories/', views.firststories, name='firststories'),
    path('singlepost/', views.singlepost, name='singlepost'),
    path('Contact/', views.Contact, name='Contact'),
    path('about/', views.About, name='about'),
    path('footer/', views.footer, name='footer'),
    path('intro/', views.introD, name='intro'),
    path('didyouknow/', views.didyouknowstr, name='didyouknow'),
    path('Story/', views.Story, name='Story'),
    path('userpage/', views.Userpage, name='userpage'),
    path('storyposts/', views.Story_posts, name='storyposts'),
    path('delete/<int:pk>/',views.delete_story,name='delete'),
    path('updatestory/<str:pk>/',views.updateStory,name='updatestory'),
]
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns += static(settings.MEDIA_URL, document_root=settings.STATIC_ROOT)
