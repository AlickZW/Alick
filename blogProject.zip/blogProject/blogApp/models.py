from django.db import models
from datetime import datetime

# Create your models here.

class didyouknow(models.Model):
    topic = models.CharField(max_length=36)
    story = models.TextField(default='',)
    friendname = models.CharField(max_length=36)
    #name,intro,my pic
    


class Headline(models.Model):
    headline_title = models.CharField(max_length =50)
    #change history para to story and also change class to blog attributes
    historypara = models.TextField(default='yoo',)
    EVENT = (
        ("team-building","team-building"),
        ("hike","hike"),
        ("explore","explore"),
    )
    event = models.CharField(max_length=13,null=False,choices=EVENT,default="explore")
    imagesrc = models.CharField(max_length=30,null=True)
    DOU = models.DateField()
    picture1 = models.ImageField(upload_to='images/')
    picture2 = models.ImageField(upload_to='images/',null=True)
    detailedstory = models.TextField(default='',)
    #picture of story being told


class Contact_d(models.Model):
    name = models.CharField(max_length=45)
    email = models.EmailField(max_length=254)
    message = models.TextField(max_length=500)

    def __str__(self):
        return self.name

    
    