from django.shortcuts import render, redirect
from blogApp.forms import Myform , Myform2
from django.contrib import messages
from .models import Headline, Contact_d, didyouknow
from PIL import Image
from django.templatetags.static import static
from django.db.models import Q



# Create your views here.c
def Home(request):
    posts = Headline.objects.all().order_by('-id')[:2]
    context = {'posts':posts,}
    return render(request, 'Home.html',context)


def Contact(request):

    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')

        contact_details = Contact_d(name=name,email=email,message=message)
        contact_details.save()
        messages.info(request,'Your message was succesfully sent!')
    return render(request, "contact.html",)

def brief_history(request):
    history = request.POST.get('history')
    print(history)
    savehistory = History()
    savehistory.historypara = history
    savehistory.save()
    return render(request, 'Home.html',)

def introD(request):
    if request.method == 'POST':
        form2=Myform2(request.POST,request.FILES)
        if form2.is_valid():
            form2.save()
            
    else:
        form2 = Myform2()
    return render(request,'introduction.html',{'form2':form2})

#def intro(request):
    ###introduct = introduction.objects.all()
    ##context = {'introduct':introduct}
    #return render(request, 'introduct.html',context)

def Story(request):
    if request.method == 'POST':
        form=Myform(request.POST,request.FILES)
        if form.is_valid():
            form.save()
    else:
        form = Myform()
    return render(request,'Add_story.html',{'form':form})

def Userpage(request):
    didyouknowstory1 = didyouknow.objects.all().order_by('-id')[:5]
    story = Headline.objects.all().order_by('-id')
    context = { 'story':story, 'didyouknowstory1':didyouknowstory1}
    return render(request, 'user_page.html', context)

def Story_posts(request):
    d = Headline.objects.all().order_by('-id')
    context = {'d':d}
    return render(request, 'storyposts.html',context)

def delete_story(request,pk):
    story = Headline.objects.get(id=pk)

    if request.method == 'POST':
        story.delete()
        return redirect('userpage')
        
    context = {'story':story}
    return render(request, 'delete.html',context,)

def updateStory(request,pk):
    story = Headline.objects.get(id=pk)
    form = Myform(instance=story)

    if request.method == 'POST':
        form = Myform(request.POST,request.FILES, instance=story)
        if form.is_valid():
            form.save()
            return redirect('userpage')
        
            
    context ={'form':form}
    return render(request,'updatestory.html',context)

def About(request):
    return render(request, 'about.html')

def index(request):
    posts = Headline.objects.all().order_by('-id')[:3]
    posts1 = Headline.objects.all().order_by('-id')[:2]
    didyouknowstory = didyouknow.objects.all().order_by('-id')[:5]
    context = {'posts1':posts1,'posts':posts, 'didyouknowstory':didyouknowstory}
    return render(request, 'index.html',context)

def singlepost(request):
    d = Headline.objects.all().order_by('-id')
    context = {'d':d}
    return render(request, 'single-post.html',context)

def firststories(request):
    return render(request, 'firststories.html',)

def didyouknowstr(request):
    return render(request, 'didyouknow.html',)

def footer(request):
    navpost = Headline.objects.all().order_by('-id')[:3]
    context = {'navpost':navpost}
    return render(request,'footer.html',context)

def services(request):
    return render(request, 'services.html')

def searchdata(request):
    query = request.GET.get('query')
    print(query)
    if query is None:
        return render(request, 'about.html')
    results = Headline.objects.filter(
        Q(event__icontains=query) |
        Q(DOU__icontains=query) |
        Q(detailedstory__icontains=query) 
           
    )
    print(results)
    context = {'results':results}
    return render(request, 'searchdata.html', context)
