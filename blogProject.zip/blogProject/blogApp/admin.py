from django.contrib import admin
from .models import Headline
from .models import Contact_d
from .models import didyouknow

# Register your models here.
admin.site.register(Headline)
admin.site.register(Contact_d)
admin.site.register(didyouknow)

