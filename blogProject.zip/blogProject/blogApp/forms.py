from django import forms
from django.forms import ModelForm
from .models import Headline, Contact_d
from .models import didyouknow


class Myform(forms.ModelForm):
    class Meta:
        model = Headline
        fields = '__all__'

class Myform1(forms.ModelForm):
    class Meta:
        model = Contact_d
        fields = '__all__'

class Myform2(forms.ModelForm):
    class Meta:
        model = didyouknow
        fields = ['story', 'friendname' , 'topic']